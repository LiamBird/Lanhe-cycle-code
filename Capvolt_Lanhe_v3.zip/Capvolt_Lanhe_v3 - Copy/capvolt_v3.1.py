from capvolt_fun import *

path = r'C:\Users\llrb2\Dropbox\DATA\Capvolt\(1-0-2)(0-10)T'
filename = r'cell4_rc'
cycles_to_show = [1, 2, 10]

capvolt_fun(path, filename, cycles_to_show)
